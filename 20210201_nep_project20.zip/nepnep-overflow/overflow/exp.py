#coding=utf-8
from LibcSearcher import *
from pwn import *
from struct import pack
context.log_level = "debug"

context.arch = "amd64"

menu="ch:"
sh = 0
lib = 0
elf =ELF('flow')
libc=ELF("/lib/x86_64-linux-gnu/libc.so.6")
""" """
l64 = lambda      :u64(sh.recvuntil("\x7f")[-6:].ljust(8,"\x00"))
l32 = lambda      :u32(sh.recvuntil("\xf7")[-4:].ljust(4,"\x00"))
leak  = lambda name,data : sh.success(name + ": 0x%x" % data)
s  = lambda payload: sh.send(payload)
sa  = lambda a,b  :sh.sendafter(str(a),str(b))
sl  = lambda payload: sh.sendline(payload)
sla = lambda a,b  :sh.sendlineafter(str(a),str(b))
ru  = lambda a     :sh.recvuntil(str(a))
r  = lambda a     :sh.recv(str(a))
""" """
def add(index,size,content):
	sla(menu,"1")
	sla("?",str(index))
	sla("??",str(size))
	sla(":",content)

def edit(index,size,content):
	sla(menu,"3")
	sla("?",str(index))
	sla("??",str(size))
	sla("say something:",content)

def delet(index):
	sla(menu,"2")
	sla("?",str(index))

def show(index):
	sla(menu,"4")
	sla("?",str(index))

def b(addr):
	# bk="b *$rebase("+str(addr)+")"
	bk="b *"+str(addr)
	attach(sh,bk)
	success("attach")
def pwn(ip,port,debug):
	global sh
	global libc
	if(debug == 1):
		sh = process("./flow")
	else:
		sh = remote(ip,port)

	add(0,0x90,"aaaa")
	edit(0,0x90,"bbbb")
	show(0)
	delet(0)


	"""
	test fastbin
	for i in range(6):
		add(i,0x60,"aaaa")
	b(0x0000000000400C6D)
	for i in range(0,6):
		delet(i)
	for i in range(6):
		add(i,0x60,"aaaa")
	"""
	"""
	test unsort bin
	add(0,0x90,"aaaa")
	add(4,0x90,"aaaa")
	add(6,0x10,"aaaa")
	add(1,0x90,"aaaa")
	add(5,0x10,"aaaa")
	add(2,0x90,"aaaa")
	add(6,0x10,"aaaa")
	add(3,0x90,"aaaa")
	delet(0)
	delet(1)
	delet(2)
	b(0x0000000000400C6D)
	delet(4)
	add(0,0x90,"aaaa")
	add(1,0x90,"aaaa")
	"""

	"""
	test smallbin 
	add(0,0x90,"aaaa")
	add(4,0x90,"aaaa")
	add(6,0x10,"aaaa")
	add(1,0x90,"aaaa")
	add(5,0x10,"aaaa")
	add(2,0x90,"aaaa")
	add(6,0x10,"aaaa")
	add(3,0x90,"aaaa")
	delet(0)
	delet(1)
	delet(2)
	b(0x0000000000400C6D)

	add(10,0x200,"aaaa")
	add(0,0x90,"aaaa")
	add(1,0x90,"aaaa")
	add(2,0x90,"aaaa")
	"""
	sh.interactive()
if __name__ == "__main__":
	pwn("aa",0,1)