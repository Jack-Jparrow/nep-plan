#include<stdio.h>

void main() {
	int i;
	printf("%134512640d%n\n",1, &i);
	printf("%x\n", i);
}
