#include<stdio.h>

void main() {
	printf("%s %d %s %x %x %x %3$s", "Hello World!", 233, "\n");
}
