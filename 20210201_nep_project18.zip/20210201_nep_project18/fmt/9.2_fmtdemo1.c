#include<stdio.h>

void main() {
	printf("%s %d %s", "Hello World!", 233, "\n");
}
